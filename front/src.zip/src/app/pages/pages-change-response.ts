import { Pages } from './pages';
export class PagesChangeResponse {
    message: string;
    pages: Pages;
}

