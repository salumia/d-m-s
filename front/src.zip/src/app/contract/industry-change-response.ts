import { Industry } from './industry';

export class IndustryChangeResponse {
  message: string;
  statusCode : number;
  industry: Industry;
}
