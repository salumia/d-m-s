import { Part } from './part';

export class PartChangeResponse {
  message: string;
  part: Part;
}
