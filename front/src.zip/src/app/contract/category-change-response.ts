import { Category } from './category';

export class CategoryChangeResponse {
  message: string;
  category: Category;
}
