import { Contract } from './contract';

export class ContractChangeResponse {
  message: string;
  contracts: Contract;
}
