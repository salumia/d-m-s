import { Set } from './set';

export class SetChangeResponse {
  message: string;
  sets: Set;
}
