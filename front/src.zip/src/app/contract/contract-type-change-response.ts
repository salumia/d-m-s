import { ContractType } from './contract-type';

export class ContractTypeChangeResponse {
  message: string;
  intractType: ContractType;
}
