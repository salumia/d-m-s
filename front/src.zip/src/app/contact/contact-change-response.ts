import { Contact } from './contact';

export class ContactChangeResponse {
  message: string;
  contact: Contact;
}
