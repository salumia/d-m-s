import { Vendor } from './vendor';

export class VendorChangeResponse {
  message: string;
  statusCode : number;
  user: Vendor;
}
