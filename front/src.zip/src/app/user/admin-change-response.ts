import { Admin } from './admin';

export class AdminChangeResponse {
  message: string;
  user: Admin;
}
